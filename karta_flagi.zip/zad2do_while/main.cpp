#include <iostream>

using namespace std;

int main()
{
    int szerokosc, wysokosc, i = 0, j = 0;
    cout << "Podaj szerokosc i wysokosc" << endl;
    cin >> szerokosc >> wysokosc;


    do
    {
        do
        {
        cout<<"\033[0;31m#";
        j++;
        }
        while(j < szerokosc );
        j = 0;
        cout<<endl;
        i++;
    }
    while(i<wysokosc/3);
    i = 0;
    j = 0;


    do
    {
        do
        {
        cout<<"\033[0;37m#";
        j++;
        }
        while(j < szerokosc );
        j = 0;
        cout<<endl;
        i++;
    }
    while(i<wysokosc/3);
    i = 0;
    j = 0;

    do
    {
        do
        {
        cout<<"\033[0;31m#";
        j++;
        }
        while(j < szerokosc );
        j = 0;
        cout<<endl;
        i++;
    }
    while(i<wysokosc/3);
    i = 0;
    j = 0;

    cout<<"\033[0m"<<endl;



    return 0;
}
