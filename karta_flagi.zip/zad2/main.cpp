#include <iostream>

using namespace std;

int main()
{
    int wysokosc, szerokosc;
    cout<<"Podaj wysokosc podzielna przez 3 i szerokosc"<<endl;
    cin>>wysokosc>>szerokosc;

    for(int i = 0; i < wysokosc /3; i++)
    {
        for(int j = 0; j< szerokosc; j++)
        {
            cout<<"\033[0;31m#";
        }
        cout<<endl;
    }

    for(int i = 0; i < wysokosc /3; i++)
    {
        for(int j = 0; j< szerokosc; j++)
        {
            cout<<"\033[0;37m#";
        }
        cout<<endl;
    }

    for(int i = 0; i < wysokosc /3; i++)
    {
        for(int j = 0; j< szerokosc; j++)
        {
            cout<<"\033[0;31m#";
        }
        cout<<endl;
    }

    cout<<"\033[0m"<<endl;

    return 0;
}
